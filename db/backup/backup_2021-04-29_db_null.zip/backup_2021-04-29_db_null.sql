--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2 (Ubuntu 13.2-1.pgdg20.04+1)
-- Dumped by pg_dump version 13.1

-- Started on 2021-04-29 10:54:33

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE stat;
--
-- TOC entry 3334 (class 1262 OID 17027)
-- Name: stat; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE stat WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'ru_RU.UTF-8';


ALTER DATABASE stat OWNER TO postgres;

\connect stat

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3335 (class 0 OID 0)
-- Name: stat; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE stat SET "TimeZone" TO 'Europe/Moscow';


\connect stat

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 6 (class 2615 OID 17292)
-- Name: stat; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA stat;


ALTER SCHEMA stat OWNER TO postgres;

--
-- TOC entry 3 (class 3079 OID 17107)
-- Name: ltree; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS ltree WITH SCHEMA public;


--
-- TOC entry 3336 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION ltree; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION ltree IS 'data type for hierarchical tree-like structures';


--
-- TOC entry 2 (class 3079 OID 17028)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 3337 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- TOC entry 344 (class 1255 OID 17293)
-- Name: get_fullname(jsonb, integer); Type: FUNCTION; Schema: stat; Owner: stat
--

CREATE FUNCTION stat.get_fullname(in_fullname jsonb, mode integer DEFAULT 0) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    lname text;
    fname text;
    mname text;
    result text default '';
BEGIN
    lname = coalesce(in_fullname->>'last_name', '');
    fname = coalesce(in_fullname->>'first_name', '');
    mname = coalesce(in_fullname->>'middle_name', '');
    result = lname;
    IF mode = 0 then
        IF fname > '' THEN 
            result = result || ' ' || fname;
            IF mname > '' THEN 
                result = result || ' ' || mname;
            END IF;
        END IF;
    ELSE
        IF fname > '' THEN
            IF mname > '' THEN 
                result = fname || ' ' || mname || ' ' || lname;
            ELSE
                result = fname || ' ' || lname;
            END IF;
        END IF;
    END IF;
    RETURN TRIM(result);
EXCEPTION
  WHEN others THEN RAISE EXCEPTION '%', sqlerrm;
END;
$$;


ALTER FUNCTION stat.get_fullname(in_fullname jsonb, mode integer) OWNER TO stat;

--
-- TOC entry 345 (class 1255 OID 17294)
-- Name: get_initials(jsonb); Type: FUNCTION; Schema: stat; Owner: stat
--

CREATE FUNCTION stat.get_initials(fullname jsonb) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
BEGIN
    RETURN UPPER(LEFT(COALESCE(fullname ->> 'first_name','n'),1) || LEFT(COALESCE(fullname ->> 'middle_name','n'),1));
EXCEPTION
    WHEN others THEN RAISE EXCEPTION '%', sqlerrm;
END;
$$;


ALTER FUNCTION stat.get_initials(fullname jsonb) OWNER TO stat;

--
-- TOC entry 346 (class 1255 OID 17295)
-- Name: get_mobilphone(text); Type: FUNCTION; Schema: stat; Owner: stat
--

CREATE FUNCTION stat.get_mobilphone(in_phone text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE 
    temp_phone text;
BEGIN
    IF in_phone ~ '9\d{9}' THEN
        temp_phone = in_phone;
    ELSE
        temp_phone = set_mobilphone(in_phone);
    END IF;
	if temp_phone > '' then
        RETURN '+7 (' || substr(temp_phone,1,3) || ') ' || substr(temp_phone,4,3) || '-' || substr(temp_phone,7,2) || '-' || substr(temp_phone,9,2);
	ELSE
		RETURN '';
	END IF;
EXCEPTION
	WHEN others THEN RAISE EXCEPTION '%', sqlerrm;
END;
$$;


ALTER FUNCTION stat.get_mobilphone(in_phone text) OWNER TO stat;

--
-- TOC entry 347 (class 1255 OID 17296)
-- Name: get_organization_by_id(bigint); Type: FUNCTION; Schema: stat; Owner: stat
--

CREATE FUNCTION stat.get_organization_by_id(in_id bigint) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    temp_organization jsonb DEFAULT '{}';
BEGIN
    SELECT jsonb_build_object(
        'id',coalesce(a.id,0),
        'name',coalesce(a.name,''),
        'full_name',coalesce(a.full_name,''),
        'short_name',coalesce(a.short_name,''),
        'client_id', coalesce(a.client_id,''),
        'client_secret',coalesce(a.client_secret,''),
        'sb_client_id',coalesce(a.sb_client_id,''),
        'sb_client_secret',coalesce(a.sb_client_secret,''),
        'sandbox',coalesce(a.sandbox,true)
    ) AS organization
    FROM organization AS a
    WHERE a.id = in_id
    INTO STRICT temp_organization;
    RETURN temp_organization;
EXCEPTION WHEN NO_DATA_FOUND THEN    
    RETURN jsonb_build_object('id',0,'name','','full_name','','short_name',''); 
END;
$$;


ALTER FUNCTION stat.get_organization_by_id(in_id bigint) OWNER TO stat;

--
-- TOC entry 348 (class 1255 OID 17297)
-- Name: get_organization_by_id_lite(bigint); Type: FUNCTION; Schema: stat; Owner: stat
--

CREATE FUNCTION stat.get_organization_by_id_lite(in_id bigint) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    temp_organization jsonb DEFAULT '{}';
BEGIN
    SELECT jsonb_build_object(
        'id',coalesce(a.id,0),
        'name',coalesce(a.name,''),
        'full_name',coalesce(a.full_name,''),
        'short_name',coalesce(a.short_name,'')
    ) AS organization
    FROM organization AS a
    WHERE a.id = in_id
    INTO STRICT temp_organization;
    RETURN temp_organization;
EXCEPTION WHEN NO_DATA_FOUND THEN    
    RETURN jsonb_build_object('id',0,'name','','full_name','','short_name',''); 
END;
$$;


ALTER FUNCTION stat.get_organization_by_id_lite(in_id bigint) OWNER TO stat;

--
-- TOC entry 349 (class 1255 OID 17298)
-- Name: get_shortname(jsonb, integer); Type: FUNCTION; Schema: stat; Owner: stat
--

CREATE FUNCTION stat.get_shortname(in_fullname jsonb, mode integer DEFAULT 0) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
	initial varchar(4) DEFAULT '';
	fname text;
	lname text;
	mname text;
BEGIN
	fname := coalesce(in_fullname->>'first_name','');
	lname := coalesce(in_fullname->>'last_name','');
	mname := coalesce(in_fullname->>'middle_name','');
	IF fname > '' THEN
		initial := LEFT(fname,1)||'.';
		IF mname > '' THEN
			initial := initial||LEFT(mname,1)||'.';
		END IF;
	END IF;
	IF mode = 0 THEN
		RETURN TRIM(lname || ' ' || initial);
	ELSE
		RETURN TRIM(initial || lname);
	END IF;
EXCEPTION
  WHEN others THEN RAISE EXCEPTION '%', sqlerrm;
END;
$$;


ALTER FUNCTION stat.get_shortname(in_fullname jsonb, mode integer) OWNER TO stat;

--
-- TOC entry 350 (class 1255 OID 17299)
-- Name: normalize_index_expression(text, bigint, integer); Type: FUNCTION; Schema: stat; Owner: stat
--

CREATE FUNCTION stat.normalize_index_expression(in_string text, in_id bigint, in_l integer) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
BEGIN
    RETURN rpad(normalize_string(in_string),in_l,' ') || lpad(in_id::text,20,'0');
END;
$$;


ALTER FUNCTION stat.normalize_index_expression(in_string text, in_id bigint, in_l integer) OWNER TO stat;

--
-- TOC entry 351 (class 1255 OID 17300)
-- Name: normalize_index_expression(text, text, integer); Type: FUNCTION; Schema: stat; Owner: postgres
--

CREATE FUNCTION stat.normalize_index_expression(in_string text, in_id text, in_l integer) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
BEGIN
    RETURN rpad(stat.normalize_string(in_string),in_l,' ') || lpad(in_id,20,'0');
END;
$$;


ALTER FUNCTION stat.normalize_index_expression(in_string text, in_id text, in_l integer) OWNER TO postgres;

--
-- TOC entry 352 (class 1255 OID 17301)
-- Name: normalize_string(text); Type: FUNCTION; Schema: stat; Owner: postgres
--

CREATE FUNCTION stat.normalize_string(in_string text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
BEGIN
    RETURN replace(upper(trim(in_string)),'Ё','Е');
END;
$$;


ALTER FUNCTION stat.normalize_string(in_string text) OWNER TO postgres;

--
-- TOC entry 353 (class 1255 OID 17302)
-- Name: organization_before_insert_or_update(); Type: FUNCTION; Schema: stat; Owner: stat
--

CREATE FUNCTION stat.organization_before_insert_or_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.index = NEW.full_name || ' ' || NEW.inn || ' ' || NEW.ogrn || ' ' || NEW.kpp;
	return NEW;
end;
$$;


ALTER FUNCTION stat.organization_before_insert_or_update() OWNER TO stat;

--
-- TOC entry 3338 (class 0 OID 0)
-- Dependencies: 353
-- Name: FUNCTION organization_before_insert_or_update(); Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON FUNCTION stat.organization_before_insert_or_update() IS 'Триггерная функция для автоматического заполнения поля index (полное наименование, ИНН, ОГРН)';


--
-- TOC entry 354 (class 1255 OID 17303)
-- Name: set_mobilphone(text); Type: FUNCTION; Schema: stat; Owner: stat
--

CREATE FUNCTION stat.set_mobilphone(in_phone text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
	res text DEFAULT '';
BEGIN	
	res := regexp_replace(in_phone,'[^0-9]','','g');
	res := regexp_replace(res,'^79','9','g');
	res := regexp_replace(res,'^89','9','g');
	IF left(res,1)= '9' AND length(res) = 10 THEN
		RETURN res;
	ELSE
		RETURN '';
	END IF;
EXCEPTION
	WHEN others THEN RAISE EXCEPTION '%', sqlerrm;
END;
$$;


ALTER FUNCTION stat.set_mobilphone(in_phone text) OWNER TO stat;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 203 (class 1259 OID 17304)
-- Name: auth_position; Type: TABLE; Schema: stat; Owner: stat
--

CREATE TABLE stat.auth_position (
    id bigint NOT NULL,
    name text,
    parent_id bigint,
    sort bigint,
    normative bigint,
    sert boolean,
    actual boolean,
    comment text,
    p_group boolean,
    data_end date
);


ALTER TABLE stat.auth_position OWNER TO stat;

--
-- TOC entry 3339 (class 0 OID 0)
-- Dependencies: 203
-- Name: TABLE auth_position; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON TABLE stat.auth_position IS 'Таблица должностей пользователей';


--
-- TOC entry 3340 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN auth_position.id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_position.id IS 'Уникальный идентификатор должности пользователя';


--
-- TOC entry 3341 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN auth_position.name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_position.name IS 'Наименование должности';


--
-- TOC entry 3342 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN auth_position.parent_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_position.parent_id IS 'Ссылка на элемент-родитель данного справочника';


--
-- TOC entry 3343 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN auth_position.sort; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_position.sort IS 'Порядок сортировки строк в исходном справочнике';


--
-- TOC entry 3344 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN auth_position.sert; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_position.sert IS 'Признак наличия сертификата';


--
-- TOC entry 3345 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN auth_position.actual; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_position.actual IS 'Признак акутальности записи';


--
-- TOC entry 3346 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN auth_position.comment; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_position.comment IS 'Комментарий';


--
-- TOC entry 3347 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN auth_position.p_group; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_position.p_group IS 'Признак группировочных записей';


--
-- TOC entry 3348 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN auth_position.data_end; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_position.data_end IS 'Дата окончания действия записи';


--
-- TOC entry 204 (class 1259 OID 17310)
-- Name: auth_position_id_seq; Type: SEQUENCE; Schema: stat; Owner: stat
--

ALTER TABLE stat.auth_position ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME stat.auth_position_id_seq
    START WITH 1000012
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 205 (class 1259 OID 17312)
-- Name: auth_role; Type: TABLE; Schema: stat; Owner: stat
--

CREATE TABLE stat.auth_role (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    organization_id bigint
);


ALTER TABLE stat.auth_role OWNER TO stat;

--
-- TOC entry 3349 (class 0 OID 0)
-- Dependencies: 205
-- Name: TABLE auth_role; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON TABLE stat.auth_role IS 'Список ролей пользователей в программе';


--
-- TOC entry 3350 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN auth_role.id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_role.id IS 'Уникальный ключ (id) для родей пользователя';


--
-- TOC entry 3351 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN auth_role.name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_role.name IS 'Наименование роли пользователя';


--
-- TOC entry 3352 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN auth_role.organization_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_role.organization_id IS 'Ссылка на таблицу организаций, внутри которых действуют эти роли';


--
-- TOC entry 206 (class 1259 OID 17315)
-- Name: auth_role_id_seq; Type: SEQUENCE; Schema: stat; Owner: stat
--

ALTER TABLE stat.auth_role ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME stat.auth_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 207 (class 1259 OID 17317)
-- Name: auth_user; Type: TABLE; Schema: stat; Owner: stat
--

CREATE TABLE stat.auth_user (
    id bigint NOT NULL,
    name character varying(50),
    full_name jsonb,
    caption text,
    password character varying(100),
    type character varying(50),
    mobil_phone character varying(10),
    active boolean DEFAULT false NOT NULL,
    roles jsonb,
    organization_id bigint,
    avatar text,
    deleted boolean DEFAULT false NOT NULL,
    thmb_avatar text,
    CONSTRAINT full_name_exists CHECK (((full_name ? 'last_name'::text) AND (full_name ? 'first_name'::text) AND (full_name ? 'middle_name'::text))),
    CONSTRAINT full_name_notnull CHECK (((full_name ->> 'last_name'::text) IS NOT NULL)),
    CONSTRAINT type_is_valid CHECK ((((type)::text = 'admin'::text) OR ((type)::text = 'user'::text)))
);


ALTER TABLE stat.auth_user OWNER TO stat;

--
-- TOC entry 3353 (class 0 OID 0)
-- Dependencies: 207
-- Name: TABLE auth_user; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON TABLE stat.auth_user IS 'Таблица для хранения учетных данных пользователей';


--
-- TOC entry 3354 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN auth_user.id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user.id IS 'Уникальный ключ (id) для пользователя';


--
-- TOC entry 3355 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN auth_user.name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user.name IS 'Имя пользователя (логин)';


--
-- TOC entry 3356 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN auth_user.full_name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user.full_name IS 'ФИО пользователя в формате JSON';


--
-- TOC entry 3357 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN auth_user.caption; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user.caption IS 'Представление (описание) пользователя';


--
-- TOC entry 3358 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN auth_user.password; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user.password IS 'Пароль пользователя в зашифрованном виде';


--
-- TOC entry 3359 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN auth_user.type; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user.type IS 'Уровень доступа (тип пользователя). Принимает значения - администратор, пользователь';


--
-- TOC entry 3360 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN auth_user.mobil_phone; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user.mobil_phone IS 'Номер мобильного телефона пользователя в упакованном виде';


--
-- TOC entry 3361 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN auth_user.active; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user.active IS 'Признак активности учетной записи, т.е. может ли пользователь входить в систему';


--
-- TOC entry 3362 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN auth_user.roles; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user.roles IS 'JSON массив ролей пользователя';


--
-- TOC entry 3363 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN auth_user.organization_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user.organization_id IS 'Ссылка на таблицу организаций к которой относится пользователь';


--
-- TOC entry 208 (class 1259 OID 17328)
-- Name: auth_user_division; Type: TABLE; Schema: stat; Owner: stat
--

CREATE TABLE stat.auth_user_division (
    period date DEFAULT CURRENT_DATE NOT NULL,
    auth_user_id bigint NOT NULL,
    division_id bigint NOT NULL,
    auth_position_id bigint,
    organization_id bigint
);


ALTER TABLE stat.auth_user_division OWNER TO stat;

--
-- TOC entry 3364 (class 0 OID 0)
-- Dependencies: 208
-- Name: TABLE auth_user_division; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON TABLE stat.auth_user_division IS 'Регистр для хранения отношения пользователя к подразделению. Имеет привязку к моменту времени';


--
-- TOC entry 3365 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN auth_user_division.period; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user_division.period IS 'Дата с которой начинает действовать привязка пользователя к подразделению';


--
-- TOC entry 3366 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN auth_user_division.auth_user_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user_division.auth_user_id IS 'Ссылка на запись в справочнике пользователей';


--
-- TOC entry 3367 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN auth_user_division.division_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user_division.division_id IS 'Ссылка на запись в справочнике отделов предприятия (подразделения)';


--
-- TOC entry 3368 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN auth_user_division.auth_position_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user_division.auth_position_id IS 'Ссылка на запись в справочнике должностей';


--
-- TOC entry 3369 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN auth_user_division.organization_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user_division.organization_id IS 'Ссылка на спарвочник организаций. Нужно для разгарничения доступа';


--
-- TOC entry 209 (class 1259 OID 17332)
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: stat; Owner: stat
--

ALTER TABLE stat.auth_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME stat.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 210 (class 1259 OID 17334)
-- Name: auth_user_socket; Type: TABLE; Schema: stat; Owner: stat
--

CREATE TABLE stat.auth_user_socket (
    socket character varying(36) NOT NULL,
    "time" timestamp without time zone DEFAULT now(),
    auth_user_id bigint
);


ALTER TABLE stat.auth_user_socket OWNER TO stat;

--
-- TOC entry 3370 (class 0 OID 0)
-- Dependencies: 210
-- Name: TABLE auth_user_socket; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON TABLE stat.auth_user_socket IS 'Справочник, в котором хранятся соотвествия пользователя и открытого сокета';


--
-- TOC entry 3371 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN auth_user_socket.socket; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user_socket.socket IS 'Уникальный идентификатор сокета';


--
-- TOC entry 3372 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN auth_user_socket."time"; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user_socket."time" IS 'Время установления соединения с сокетом';


--
-- TOC entry 3373 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN auth_user_socket.auth_user_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.auth_user_socket.auth_user_id IS 'Уникальный идентификатор пользователя';


--
-- TOC entry 211 (class 1259 OID 17338)
-- Name: division; Type: TABLE; Schema: stat; Owner: stat
--

CREATE TABLE stat.division (
    id bigint NOT NULL,
    parent_id bigint,
    organization_id bigint,
    name text NOT NULL,
    short_name text,
    prefix character varying(10),
    oid character varying(100)
);


ALTER TABLE stat.division OWNER TO stat;

--
-- TOC entry 3374 (class 0 OID 0)
-- Dependencies: 211
-- Name: TABLE division; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON TABLE stat.division IS 'Справочник подразделений';


--
-- TOC entry 3375 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN division.id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.division.id IS 'Уникальный ключ для подразделений';


--
-- TOC entry 3376 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN division.parent_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.division.parent_id IS 'Ссылка на родительское подразделение';


--
-- TOC entry 3377 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN division.organization_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.division.organization_id IS 'Ссылка на организацию к которой относится подразделение';


--
-- TOC entry 3378 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN division.name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.division.name IS 'Наименование подразделения';


--
-- TOC entry 3379 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN division.short_name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.division.short_name IS 'Сокращенное наименование подразделения';


--
-- TOC entry 3380 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN division.prefix; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.division.prefix IS 'Префикс подразделения (например для выгрузки в бухгалтерию)';


--
-- TOC entry 212 (class 1259 OID 17344)
-- Name: division_id_seq; Type: SEQUENCE; Schema: stat; Owner: stat
--

ALTER TABLE stat.division ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME stat.division_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 213 (class 1259 OID 17346)
-- Name: federal_subject; Type: TABLE; Schema: stat; Owner: stat
--

CREATE TABLE stat.federal_subject (
    id character(2) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE stat.federal_subject OWNER TO stat;

--
-- TOC entry 3381 (class 0 OID 0)
-- Dependencies: 213
-- Name: TABLE federal_subject; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON TABLE stat.federal_subject IS 'Справочник федеральных субъектов';


--
-- TOC entry 3382 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN federal_subject.id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.federal_subject.id IS 'Код федерального субъекта';


--
-- TOC entry 3383 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN federal_subject.name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.federal_subject.name IS 'Наименование федерального субъекта';


--
-- TOC entry 214 (class 1259 OID 17349)
-- Name: finance_source; Type: TABLE; Schema: stat; Owner: stat
--

CREATE TABLE stat.finance_source (
    id bigint NOT NULL,
    name text NOT NULL,
    b_date date NOT NULL,
    e_date date,
    deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT positiv_date CHECK (((b_date < e_date) OR (e_date = NULL::date)))
);


ALTER TABLE stat.finance_source OWNER TO stat;

--
-- TOC entry 3384 (class 0 OID 0)
-- Dependencies: 214
-- Name: TABLE finance_source; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON TABLE stat.finance_source IS 'Источники финансирования';


--
-- TOC entry 3385 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN finance_source.id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.finance_source.id IS 'Ид. источника финансирования';


--
-- TOC entry 3386 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN finance_source.name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.finance_source.name IS 'Наименование источника финансирования';


--
-- TOC entry 3387 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN finance_source.b_date; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.finance_source.b_date IS 'Начальная дата действия источника финансирования';


--
-- TOC entry 3388 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN finance_source.e_date; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.finance_source.e_date IS 'Конечная  дата действия источника финансирования';


--
-- TOC entry 3389 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN finance_source.deleted; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.finance_source.deleted IS 'Признак удаления записи шаблона';


--
-- TOC entry 3390 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN finance_source.created_at; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.finance_source.created_at IS 'Дата записи';


--
-- TOC entry 3391 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN finance_source.deleted_at; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.finance_source.deleted_at IS 'Дата удаления';


--
-- TOC entry 215 (class 1259 OID 17358)
-- Name: finance_source_id_seq; Type: SEQUENCE; Schema: stat; Owner: stat
--

ALTER TABLE stat.finance_source ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME stat.finance_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 216 (class 1259 OID 17360)
-- Name: input_file; Type: TABLE; Schema: stat; Owner: stat
--

CREATE TABLE stat.input_file (
    id bigint NOT NULL,
    template_id bigint,
    organization_id bigint,
    division_id bigint,
    uuid uuid NOT NULL,
    name text NOT NULL,
    path text NOT NULL,
    period date NOT NULL,
    status jsonb DEFAULT '{"handled": false, "validation": false}'::jsonb NOT NULL,
    auth_user_id bigint,
    deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    data jsonb,
    protocol_errors jsonb
);


ALTER TABLE stat.input_file OWNER TO stat;

--
-- TOC entry 3392 (class 0 OID 0)
-- Dependencies: 216
-- Name: TABLE input_file; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON TABLE stat.input_file IS 'Файл входящий на проверку';


--
-- TOC entry 3393 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.id IS 'Ид. фходящего файла';


--
-- TOC entry 3394 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.template_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.template_id IS 'Ид. шаблона входящего файла';


--
-- TOC entry 3395 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.organization_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.organization_id IS 'Ид. организации';


--
-- TOC entry 3396 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.division_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.division_id IS 'Ид. подразделения';


--
-- TOC entry 3397 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.uuid; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.uuid IS 'UUID присвоенное фходящем файлу в системе';


--
-- TOC entry 3398 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.name IS 'Наименование оригинала входящего файла';


--
-- TOC entry 3399 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.path; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.path IS 'Путь хранения зарженного файла в системе';


--
-- TOC entry 3400 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.period; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.period IS 'Дата расчетного периода ';


--
-- TOC entry 3401 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.status; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.status IS 'Статус проверки файла validation=true - валидация пройдена успешно, handled=true ручная операция разрешения на отправку файла';


--
-- TOC entry 3402 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.auth_user_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.auth_user_id IS 'Ид.пользователя загрузившего файл';


--
-- TOC entry 3403 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.deleted; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.deleted IS 'Признак удаления записи шаблона';


--
-- TOC entry 3404 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.created_at; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.created_at IS 'Дата записи';


--
-- TOC entry 3405 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.deleted_at; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.deleted_at IS 'Дата удаления';


--
-- TOC entry 3406 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.data; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.data IS 'Данные загружаемого файла';


--
-- TOC entry 3407 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN input_file.protocol_errors; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.input_file.protocol_errors IS 'Протокол ошибок валидации данных';


--
-- TOC entry 217 (class 1259 OID 17369)
-- Name: input_file_id_seq; Type: SEQUENCE; Schema: stat; Owner: stat
--

ALTER TABLE stat.input_file ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME stat.input_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 218 (class 1259 OID 17384)
-- Name: organization; Type: TABLE; Schema: stat; Owner: stat
--

CREATE TABLE stat.organization (
    id bigint NOT NULL,
    name text NOT NULL,
    short_name text NOT NULL,
    full_name text,
    prefix character varying(3),
    inn character varying(12),
    kpp character varying(9),
    ogrn character varying(15),
    details jsonb,
    contacts jsonb,
    legal_address jsonb DEFAULT '{"fias": "true", "flat": "", "house": "", "aoguid": "", "houseguid": "", "post_code": "", "full_address": ""}'::jsonb,
    post_address jsonb DEFAULT '{"fias": "true", "flat": "", "house": "", "aoguid": "", "houseguid": "", "post_code": "", "full_address": ""}'::jsonb,
    bank_details jsonb,
    sys_id character varying(36),
    type smallint DEFAULT 0,
    type_ip boolean DEFAULT false,
    deleted boolean DEFAULT false NOT NULL,
    index character varying(500),
    oid character varying(50),
    federal_subject_id character(2),
    client_id character varying(36),
    client_secret character varying(36),
    sb_client_secret character varying(36),
    sb_client_id character varying(36),
    sandbox boolean DEFAULT true,
    pharmacy_oid character varying(50),
    name_subject_mo text,
    list_oid text[]
);


ALTER TABLE stat.organization OWNER TO stat;

--
-- TOC entry 3408 (class 0 OID 0)
-- Dependencies: 218
-- Name: TABLE organization; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON TABLE stat.organization IS 'Справочник организаций';


--
-- TOC entry 3409 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.id IS 'Уникальный ключ (id) для организаций';


--
-- TOC entry 3410 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.name IS 'Общеупотребительное наименование организации. Используется в списках выбора';


--
-- TOC entry 3411 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.short_name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.short_name IS 'Сокращенное официальное наименование организации';


--
-- TOC entry 3412 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.full_name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.full_name IS 'Полное официальное наименование организации';


--
-- TOC entry 3413 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.prefix; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.prefix IS 'Префикс организации';


--
-- TOC entry 3414 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.inn; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.inn IS 'ИНН организации';


--
-- TOC entry 3415 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.kpp; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.kpp IS 'КПП организации';


--
-- TOC entry 3416 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.ogrn; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.ogrn IS 'ОГРН/ОГРНИП организации (ИП)';


--
-- TOC entry 3417 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.details; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.details IS 'Дополнительные детали и реквизиты организации';


--
-- TOC entry 3418 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.contacts; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.contacts IS 'Контакты организации, обязательные поля - email и phone';


--
-- TOC entry 3419 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.legal_address; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.legal_address IS 'Юридический адрес организации';


--
-- TOC entry 3420 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.post_address; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.post_address IS 'Почтовый адрес организации';


--
-- TOC entry 3421 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.bank_details; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.bank_details IS 'Банковские реквизиты организации';


--
-- TOC entry 3422 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.sys_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.sys_id IS 'Уникальный ИД организации в системе МДЛП';


--
-- TOC entry 3423 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.type; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.type IS 'Тип организации. 0 - свои организации, 1 - контрагенты';


--
-- TOC entry 3424 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.type_ip; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.type_ip IS 'Признак индивидуального предпринимателя';


--
-- TOC entry 3425 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.client_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.client_id IS 'Идентификатор учетной системы для организцаии в системе МДЛП';


--
-- TOC entry 3426 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.client_secret; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.client_secret IS 'Секретный код учетной системы для организации в системе МДЛП';


--
-- TOC entry 3427 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.sb_client_secret; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.sb_client_secret IS 'Секретный код учетной системы для организации в системе МДЛП (тестовый контур)';


--
-- TOC entry 3428 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.sb_client_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.sb_client_id IS 'Идентификатор учетной системы для организации в системе МДЛП (тестовый контур)';


--
-- TOC entry 3429 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.sandbox; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.sandbox IS 'Признак ратобы в тестовом контуре системы МДЛП';


--
-- TOC entry 3430 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.pharmacy_oid; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.pharmacy_oid IS 'OID фармацевтической организации';


--
-- TOC entry 3431 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.name_subject_mo; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.name_subject_mo IS 'Наименование субъекта системы здравоохранения';


--
-- TOC entry 3432 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN organization.list_oid; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.organization.list_oid IS 'Список oid организации';


--
-- TOC entry 219 (class 1259 OID 17396)
-- Name: organization_id_seq; Type: SEQUENCE; Schema: stat; Owner: stat
--

ALTER TABLE stat.organization ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME stat.organization_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 220 (class 1259 OID 17398)
-- Name: template; Type: TABLE; Schema: stat; Owner: stat
--

CREATE TABLE stat.template (
    id bigint NOT NULL,
    type_report_id bigint,
    name text NOT NULL,
    schema_validation jsonb,
    template_file text NOT NULL,
    deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    period date,
    e_date date
);


ALTER TABLE stat.template OWNER TO stat;

--
-- TOC entry 3433 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE template; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON TABLE stat.template IS 'Шаблон';


--
-- TOC entry 3434 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN template.id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.template.id IS 'Ид. шаблона';


--
-- TOC entry 3435 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN template.type_report_id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.template.type_report_id IS 'Ид. типа/вида отчетности';


--
-- TOC entry 3436 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN template.name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.template.name IS 'Наименование шаблона';


--
-- TOC entry 3437 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN template.schema_validation; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.template.schema_validation IS 'Схема валидации полей в таблице шаблона';


--
-- TOC entry 3438 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN template.template_file; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.template.template_file IS 'Имя файл шаблона в формате xlsx';


--
-- TOC entry 3439 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN template.deleted; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.template.deleted IS 'Признак удаления записи шаблона';


--
-- TOC entry 3440 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN template.created_at; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.template.created_at IS 'Дата записи';


--
-- TOC entry 3441 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN template.deleted_at; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.template.deleted_at IS 'Дата удаления';


--
-- TOC entry 3442 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN template.period; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.template.period IS 'Период актуализации шаблона, действующие значения год и месяц предоставления отчетов';


--
-- TOC entry 3443 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN template.e_date; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.template.e_date IS 'Дата окончания действия шаблона';


--
-- TOC entry 221 (class 1259 OID 17406)
-- Name: template_id_seq; Type: SEQUENCE; Schema: stat; Owner: stat
--

ALTER TABLE stat.template ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME stat.template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 222 (class 1259 OID 17408)
-- Name: type_report; Type: TABLE; Schema: stat; Owner: stat
--

CREATE TABLE stat.type_report (
    id bigint NOT NULL,
    name text NOT NULL,
    deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE stat.type_report OWNER TO stat;

--
-- TOC entry 3444 (class 0 OID 0)
-- Dependencies: 222
-- Name: TABLE type_report; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON TABLE stat.type_report IS 'Тип отчетности';


--
-- TOC entry 3445 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN type_report.id; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.type_report.id IS 'Ид. типа отчетности';


--
-- TOC entry 3446 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN type_report.name; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.type_report.name IS 'Наименование шаблона';


--
-- TOC entry 3447 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN type_report.deleted; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.type_report.deleted IS 'Признак удаления записи шаблона';


--
-- TOC entry 3448 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN type_report.created_at; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.type_report.created_at IS 'Дата записи';


--
-- TOC entry 3449 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN type_report.deleted_at; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON COLUMN stat.type_report.deleted_at IS 'Дата удаления';


--
-- TOC entry 223 (class 1259 OID 17416)
-- Name: type_report_id_seq; Type: SEQUENCE; Schema: stat; Owner: stat
--

ALTER TABLE stat.type_report ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME stat.type_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 3126 (class 2606 OID 17519)
-- Name: auth_position auth_position_pkey; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_position
    ADD CONSTRAINT auth_position_pkey PRIMARY KEY (id);


--
-- TOC entry 3132 (class 2606 OID 17521)
-- Name: auth_role auth_role_pkey; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_role
    ADD CONSTRAINT auth_role_pkey PRIMARY KEY (id);


--
-- TOC entry 3143 (class 2606 OID 17523)
-- Name: auth_user_division auth_user_division_pkey; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_user_division
    ADD CONSTRAINT auth_user_division_pkey PRIMARY KEY (period, auth_user_id);


--
-- TOC entry 3137 (class 2606 OID 17525)
-- Name: auth_user auth_user_name_key; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_user
    ADD CONSTRAINT auth_user_name_key UNIQUE (name);


--
-- TOC entry 3139 (class 2606 OID 17527)
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- TOC entry 3146 (class 2606 OID 17529)
-- Name: auth_user_socket auth_user_socket_pkey; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_user_socket
    ADD CONSTRAINT auth_user_socket_pkey PRIMARY KEY (socket);


--
-- TOC entry 3151 (class 2606 OID 17531)
-- Name: division division_pkey; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.division
    ADD CONSTRAINT division_pkey PRIMARY KEY (id);


--
-- TOC entry 3156 (class 2606 OID 17533)
-- Name: federal_subject federal_subject_pkey; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.federal_subject
    ADD CONSTRAINT federal_subject_pkey PRIMARY KEY (id);


--
-- TOC entry 3159 (class 2606 OID 17535)
-- Name: finance_source finance_source_pkey; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.finance_source
    ADD CONSTRAINT finance_source_pkey PRIMARY KEY (id);


--
-- TOC entry 3162 (class 2606 OID 17537)
-- Name: input_file input_file_pkey; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.input_file
    ADD CONSTRAINT input_file_pkey PRIMARY KEY (id);


--
-- TOC entry 3170 (class 2606 OID 17541)
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- TOC entry 3172 (class 2606 OID 17543)
-- Name: template template_pkey; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.template
    ADD CONSTRAINT template_pkey PRIMARY KEY (id);


--
-- TOC entry 3174 (class 2606 OID 17545)
-- Name: template template_unique_constraint_id_period; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.template
    ADD CONSTRAINT template_unique_constraint_id_period UNIQUE (id, period);


--
-- TOC entry 3176 (class 2606 OID 17547)
-- Name: template template_unique_constraint_type_period; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.template
    ADD CONSTRAINT template_unique_constraint_type_period UNIQUE (type_report_id, period);


--
-- TOC entry 3178 (class 2606 OID 17549)
-- Name: type_report type_report_pkey; Type: CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.type_report
    ADD CONSTRAINT type_report_pkey PRIMARY KEY (id);


--
-- TOC entry 3122 (class 1259 OID 17550)
-- Name: auth_position_data_end_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX auth_position_data_end_btree_idx ON stat.auth_position USING btree (data_end) WHERE (data_end IS NOT NULL);


--
-- TOC entry 3450 (class 0 OID 0)
-- Dependencies: 3122
-- Name: INDEX auth_position_data_end_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.auth_position_data_end_btree_idx IS 'Индекс для ограничения выборки профессий по дате актуальности';


--
-- TOC entry 3123 (class 1259 OID 17551)
-- Name: auth_position_name_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX auth_position_name_btree_idx ON stat.auth_position USING btree (stat.normalize_string(name));


--
-- TOC entry 3124 (class 1259 OID 17552)
-- Name: auth_position_name_gin_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX auth_position_name_gin_idx ON stat.auth_position USING gin (stat.normalize_string(name) public.gin_trgm_ops);


--
-- TOC entry 3128 (class 1259 OID 17553)
-- Name: auth_role_name_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX auth_role_name_btree_idx ON stat.auth_role USING btree (stat.normalize_string((name)::text));


--
-- TOC entry 3451 (class 0 OID 0)
-- Dependencies: 3128
-- Name: INDEX auth_role_name_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.auth_role_name_btree_idx IS 'Индекс для поиска по полному совпадению наименования в таблице ролей пользователя';


--
-- TOC entry 3129 (class 1259 OID 17554)
-- Name: auth_role_name_gin_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX auth_role_name_gin_idx ON stat.auth_role USING gin (stat.normalize_string((name)::text) public.gin_trgm_ops);


--
-- TOC entry 3452 (class 0 OID 0)
-- Dependencies: 3129
-- Name: INDEX auth_role_name_gin_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.auth_role_name_gin_idx IS 'Индекс для поиска по вхождению подстроки в наименование в таблице ролей пользователя';


--
-- TOC entry 3130 (class 1259 OID 17555)
-- Name: auth_role_page_navigation_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX auth_role_page_navigation_btree_idx ON stat.auth_role USING btree (stat.normalize_index_expression((name)::text, id, 50));


--
-- TOC entry 3133 (class 1259 OID 17556)
-- Name: auth_user_branch_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX auth_user_branch_btree_idx ON stat.auth_user USING btree (mobil_phone);


--
-- TOC entry 3140 (class 1259 OID 17557)
-- Name: auth_user_division_division_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX auth_user_division_division_btree_idx ON stat.auth_user_division USING btree (division_id);


--
-- TOC entry 3141 (class 1259 OID 17558)
-- Name: auth_user_division_period_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX auth_user_division_period_btree_idx ON stat.auth_user_division USING btree (period);


--
-- TOC entry 3453 (class 0 OID 0)
-- Dependencies: 3141
-- Name: INDEX auth_user_division_period_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.auth_user_division_period_btree_idx IS 'Индекс для отбора и сортировке по дате изменения';


--
-- TOC entry 3144 (class 1259 OID 17559)
-- Name: auth_user_division_position_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX auth_user_division_position_btree_idx ON stat.auth_user_division USING btree (auth_position_id);


--
-- TOC entry 3134 (class 1259 OID 17560)
-- Name: auth_user_name_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX auth_user_name_btree_idx ON stat.auth_user USING btree (stat.normalize_string((name)::text));


--
-- TOC entry 3454 (class 0 OID 0)
-- Dependencies: 3134
-- Name: INDEX auth_user_name_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.auth_user_name_btree_idx IS 'Индекс для поиска по полному совпадению наименования в таблице должностей';


--
-- TOC entry 3135 (class 1259 OID 17561)
-- Name: auth_user_name_gin_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX auth_user_name_gin_idx ON stat.auth_user USING gin (stat.normalize_string(stat.get_fullname(full_name)) public.gin_trgm_ops);


--
-- TOC entry 3455 (class 0 OID 0)
-- Dependencies: 3135
-- Name: INDEX auth_user_name_gin_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.auth_user_name_gin_idx IS 'Индекс для поиска по вхождению подстроки в наименование в таблице должностей';


--
-- TOC entry 3147 (class 1259 OID 17563)
-- Name: division_name_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX division_name_btree_idx ON stat.division USING btree (stat.normalize_string(name));


--
-- TOC entry 3456 (class 0 OID 0)
-- Dependencies: 3147
-- Name: INDEX division_name_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.division_name_btree_idx IS 'Индекс для поиска по полному совпадению наименования в таблице подразделения организации';


--
-- TOC entry 3148 (class 1259 OID 17564)
-- Name: division_name_gin_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX division_name_gin_idx ON stat.division USING gin (stat.normalize_string(name) public.gin_trgm_ops);


--
-- TOC entry 3457 (class 0 OID 0)
-- Dependencies: 3148
-- Name: INDEX division_name_gin_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.division_name_gin_idx IS 'Индекс для поиска по вхождению подстроки в наименование в таблице подразделения организации';


--
-- TOC entry 3149 (class 1259 OID 17565)
-- Name: division_oid_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX division_oid_btree_idx ON stat.division USING btree (oid);


--
-- TOC entry 3458 (class 0 OID 0)
-- Dependencies: 3149
-- Name: INDEX division_oid_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.division_oid_btree_idx IS 'Индекс для поиска по точному совпадению OID в таблице подразделения организации';


--
-- TOC entry 3152 (class 1259 OID 17567)
-- Name: federal_subject_name_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX federal_subject_name_btree_idx ON stat.federal_subject USING btree (stat.normalize_string((name)::text));


--
-- TOC entry 3459 (class 0 OID 0)
-- Dependencies: 3152
-- Name: INDEX federal_subject_name_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.federal_subject_name_btree_idx IS 'Индекс для поиска по полному совпадению наименования в таблице субъектов РФ';


--
-- TOC entry 3153 (class 1259 OID 17568)
-- Name: federal_subject_name_gin_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX federal_subject_name_gin_idx ON stat.federal_subject USING gin (stat.normalize_string((name)::text) public.gin_trgm_ops);


--
-- TOC entry 3460 (class 0 OID 0)
-- Dependencies: 3153
-- Name: INDEX federal_subject_name_gin_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.federal_subject_name_gin_idx IS 'Индекс для поиска по вхождению подстроки в наименование в таблице субъектов РФ';


--
-- TOC entry 3154 (class 1259 OID 17569)
-- Name: federal_subject_page_navigation_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX federal_subject_page_navigation_btree_idx ON stat.federal_subject USING btree (stat.normalize_index_expression((name)::text, (id)::text, 50));


--
-- TOC entry 3461 (class 0 OID 0)
-- Dependencies: 3154
-- Name: INDEX federal_subject_page_navigation_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.federal_subject_page_navigation_btree_idx IS 'Индекс для постраничной навигации в таблице субъектов РФ';


--
-- TOC entry 3157 (class 1259 OID 17570)
-- Name: finance_source_lower_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX finance_source_lower_idx ON stat.finance_source USING btree (lower(name));


--
-- TOC entry 3127 (class 1259 OID 17571)
-- Name: fki_auth_position_auth_position_id_fkey; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX fki_auth_position_auth_position_id_fkey ON stat.auth_position USING btree (parent_id);


--
-- TOC entry 3160 (class 1259 OID 17572)
-- Name: fki_input_file_auth_user_id_fkey; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX fki_input_file_auth_user_id_fkey ON stat.input_file USING btree (auth_user_id);


--
-- TOC entry 3164 (class 1259 OID 17573)
-- Name: organization_inn_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX organization_inn_btree_idx ON stat.organization USING btree (inn);


--
-- TOC entry 3462 (class 0 OID 0)
-- Dependencies: 3164
-- Name: INDEX organization_inn_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.organization_inn_btree_idx IS 'Индекс для поиска по точному совпадению ИНН в таблице организации';


--
-- TOC entry 3165 (class 1259 OID 17574)
-- Name: organization_kpp_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX organization_kpp_btree_idx ON stat.organization USING btree (kpp);


--
-- TOC entry 3463 (class 0 OID 0)
-- Dependencies: 3165
-- Name: INDEX organization_kpp_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.organization_kpp_btree_idx IS 'Индекс для поиска по точному совпадению КПП в таблице организации';


--
-- TOC entry 3166 (class 1259 OID 17575)
-- Name: organization_name_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX organization_name_btree_idx ON stat.organization USING btree (stat.normalize_string(name));


--
-- TOC entry 3464 (class 0 OID 0)
-- Dependencies: 3166
-- Name: INDEX organization_name_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.organization_name_btree_idx IS 'Индекс для поиска по полному совпадению наименования в таблице организации';


--
-- TOC entry 3167 (class 1259 OID 17576)
-- Name: organization_name_gin_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX organization_name_gin_idx ON stat.organization USING gin (stat.normalize_string(name) public.gin_trgm_ops);


--
-- TOC entry 3465 (class 0 OID 0)
-- Dependencies: 3167
-- Name: INDEX organization_name_gin_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.organization_name_gin_idx IS 'Индекс для поиска по вхождению подстроки в наименование в таблице организации';


--
-- TOC entry 3168 (class 1259 OID 17577)
-- Name: organization_oid_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX organization_oid_btree_idx ON stat.organization USING btree (oid);


--
-- TOC entry 3466 (class 0 OID 0)
-- Dependencies: 3168
-- Name: INDEX organization_oid_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.organization_oid_btree_idx IS 'Индекс для поиска по точному совпадению OID в таблице организации';


--
-- TOC entry 3163 (class 1259 OID 17578)
-- Name: stat_input_file_uuid_btree_idx; Type: INDEX; Schema: stat; Owner: stat
--

CREATE INDEX stat_input_file_uuid_btree_idx ON stat.input_file USING btree (uuid);


--
-- TOC entry 3467 (class 0 OID 0)
-- Dependencies: 3163
-- Name: INDEX stat_input_file_uuid_btree_idx; Type: COMMENT; Schema: stat; Owner: stat
--

COMMENT ON INDEX stat.stat_input_file_uuid_btree_idx IS 'Индекс для поиска по уникальному UUID';


--
-- TOC entry 3324 (class 2618 OID 17579)
-- Name: finance_source delete_stat_finance_source; Type: RULE; Schema: stat; Owner: stat
--

CREATE RULE delete_stat_finance_source AS
    ON DELETE TO stat.finance_source DO INSTEAD  UPDATE stat.finance_source SET deleted = true, deleted_at = now()
  WHERE (finance_source.id = old.id);


--
-- TOC entry 3328 (class 2618 OID 17667)
-- Name: input_file delete_stat_input_file; Type: RULE; Schema: stat; Owner: stat
--

CREATE RULE delete_stat_input_file AS
    ON DELETE TO stat.input_file DO INSTEAD  UPDATE stat.input_file SET deleted = true, deleted_at = now()
  WHERE (input_file.id = old.id)
  RETURNING input_file.id,
    input_file.template_id,
    input_file.organization_id,
    input_file.division_id,
    input_file.uuid,
    input_file.name,
    input_file.path,
    input_file.period,
    input_file.status,
    input_file.auth_user_id,
    input_file.deleted,
    input_file.created_at,
    input_file.deleted_at,
    input_file.data,
    input_file.protocol_errors;


--
-- TOC entry 3325 (class 2618 OID 17580)
-- Name: template delete_stat_template; Type: RULE; Schema: stat; Owner: stat
--

CREATE RULE delete_stat_template AS
    ON DELETE TO stat.template DO INSTEAD  UPDATE stat.template SET deleted = true, deleted_at = now()
  WHERE (template.id = old.id);


--
-- TOC entry 3326 (class 2618 OID 17581)
-- Name: type_report delete_stat_type_report; Type: RULE; Schema: stat; Owner: stat
--

CREATE RULE delete_stat_type_report AS
    ON DELETE TO stat.type_report DO INSTEAD  UPDATE stat.type_report SET deleted = true, deleted_at = now()
  WHERE (type_report.id = old.id);


--
-- TOC entry 3327 (class 2618 OID 17582)
-- Name: type_report update_stat_type_report; Type: RULE; Schema: stat; Owner: stat
--

CREATE RULE update_stat_type_report AS
    ON UPDATE TO stat.type_report DO INSTEAD NOTHING;


--
-- TOC entry 3193 (class 2620 OID 17583)
-- Name: organization organization_before_insert_or_update; Type: TRIGGER; Schema: stat; Owner: stat
--

CREATE TRIGGER organization_before_insert_or_update BEFORE INSERT OR UPDATE ON stat.organization FOR EACH ROW EXECUTE FUNCTION stat.organization_before_insert_or_update();


--
-- TOC entry 3179 (class 2606 OID 17584)
-- Name: auth_position auth_position_auth_position_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_position
    ADD CONSTRAINT auth_position_auth_position_id_fkey FOREIGN KEY (parent_id) REFERENCES stat.auth_position(id);


--
-- TOC entry 3180 (class 2606 OID 17589)
-- Name: auth_role auth_role_organization_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_role
    ADD CONSTRAINT auth_role_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES stat.organization(id);


--
-- TOC entry 3182 (class 2606 OID 17594)
-- Name: auth_user_division auth_user_division_auth_position_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_user_division
    ADD CONSTRAINT auth_user_division_auth_position_id_fkey FOREIGN KEY (auth_position_id) REFERENCES stat.auth_position(id);


--
-- TOC entry 3183 (class 2606 OID 17599)
-- Name: auth_user_division auth_user_division_auth_user_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_user_division
    ADD CONSTRAINT auth_user_division_auth_user_id_fkey FOREIGN KEY (auth_user_id) REFERENCES stat.auth_user(id);


--
-- TOC entry 3184 (class 2606 OID 17604)
-- Name: auth_user_division auth_user_division_division_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_user_division
    ADD CONSTRAINT auth_user_division_division_id_fkey FOREIGN KEY (division_id) REFERENCES stat.division(id);


--
-- TOC entry 3185 (class 2606 OID 17609)
-- Name: auth_user_division auth_user_division_organization_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_user_division
    ADD CONSTRAINT auth_user_division_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES stat.organization(id);


--
-- TOC entry 3181 (class 2606 OID 17614)
-- Name: auth_user auth_user_organization_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_user
    ADD CONSTRAINT auth_user_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES stat.organization(id);


--
-- TOC entry 3186 (class 2606 OID 17619)
-- Name: auth_user_socket auth_user_socket_auth_user_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.auth_user_socket
    ADD CONSTRAINT auth_user_socket_auth_user_id_fkey FOREIGN KEY (auth_user_id) REFERENCES stat.auth_user(id);


--
-- TOC entry 3187 (class 2606 OID 17624)
-- Name: division division_organization_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.division
    ADD CONSTRAINT division_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES stat.organization(id);


--
-- TOC entry 3188 (class 2606 OID 17629)
-- Name: division division_parent_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.division
    ADD CONSTRAINT division_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES stat.division(id);


--
-- TOC entry 3189 (class 2606 OID 17634)
-- Name: input_file input_file_auth_user_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.input_file
    ADD CONSTRAINT input_file_auth_user_id_fkey FOREIGN KEY (auth_user_id) REFERENCES stat.auth_user(id) NOT VALID;


--
-- TOC entry 3190 (class 2606 OID 17639)
-- Name: input_file input_file_organization_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.input_file
    ADD CONSTRAINT input_file_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES stat.organization(id);


--
-- TOC entry 3191 (class 2606 OID 17644)
-- Name: organization organization_federal_subject_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.organization
    ADD CONSTRAINT organization_federal_subject_id_fkey FOREIGN KEY (federal_subject_id) REFERENCES stat.federal_subject(id);


--
-- TOC entry 3192 (class 2606 OID 17649)
-- Name: template template_type_report_id_fkey; Type: FK CONSTRAINT; Schema: stat; Owner: stat
--

ALTER TABLE ONLY stat.template
    ADD CONSTRAINT template_type_report_id_fkey FOREIGN KEY (type_report_id) REFERENCES stat.type_report(id);


-- Completed on 2021-04-29 10:54:35

--
-- PostgreSQL database dump complete
--

